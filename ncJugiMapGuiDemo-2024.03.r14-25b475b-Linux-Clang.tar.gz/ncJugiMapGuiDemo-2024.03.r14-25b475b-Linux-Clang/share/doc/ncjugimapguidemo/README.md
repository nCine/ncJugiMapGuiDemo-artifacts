[![Linux](https://github.com/nCine/ncJugiMapGuiDemo/workflows/Linux/badge.svg)](https://github.com/nCine/ncJugiMapGuiDemo/actions?workflow=Linux)
[![macOS](https://github.com/nCine/ncJugiMapGuiDemo/workflows/macOS/badge.svg)](https://github.com/nCine/ncJugiMapGuiDemo/actions?workflow=macOS)
[![Windows](https://github.com/nCine/ncJugiMapGuiDemo/workflows/Windows/badge.svg)](https://github.com/nCine/ncJugiMapGuiDemo/actions?workflow=Windows)
[![MinGW](https://github.com/nCine/ncJugiMapGuiDemo/workflows/MinGW/badge.svg)](https://github.com/nCine/ncJugiMapGuiDemo/actions?workflow=MinGW)
[![Emscripten](https://github.com/nCine/ncJugiMapGuiDemo/workflows/Emscripten/badge.svg)](https://github.com/nCine/ncJugiMapGuiDemo/actions?workflow=Emscripten)
[![Android](https://github.com/nCine/ncJugiMapGuiDemo/workflows/Android/badge.svg)](https://github.com/nCine/ncJugiMapGuiDemo/actions?workflow=Android)
[![CodeQL](https://github.com/nCine/ncJugiMapGuiDemo/workflows/CodeQL/badge.svg)](https://github.com/nCine/ncJugiMapGuiDemo/actions?workflow=CodeQL)

# ncJugiMapGuiDemo
A nCine port of the [JugiMap](http://jugimap.com) [Gui](https://github.com/Jugilus/JugimapFramework) Demo by [Jugilus](https://github.com/Jugilus).

The JugiMap Framework is distributed under the [MIT License](https://github.com/Jugilus/JugimapFramework/blob/master/LICENSE) and is Copyright (c) 2019 Jugilus.
