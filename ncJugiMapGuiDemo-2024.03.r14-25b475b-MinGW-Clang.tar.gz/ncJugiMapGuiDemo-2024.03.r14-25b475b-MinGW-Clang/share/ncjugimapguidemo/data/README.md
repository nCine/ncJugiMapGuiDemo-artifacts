# Data files for the *ncJugiMapGuiDemo* project

## Icons

- The images in the `icons` folder have been created by Angelo Theodorou for the ncJugiMapGuiDemo project assembling together images from the media folder of https://github.com/Jugilus/JugiMapFramework
